#include <alumni.h>

LD* signInDetails(LD *ld, int _id)
{
        LD *newNode =NULL;
        LD *head = NULL;
        head = ld;

        newNode = (LD *)malloc(sizeof(LD));
        newNode->next = NULL;

        if(head == NULL)
        {
                //no records
                head = newNode;
                ld = newNode;
                printf("\n\tNNPD");
        }
        else
        {
                //records are present
                while(ld->next != NULL)
                        ld = ld->next;

                ld->next = newNode;
                ld = ld->next;
                printf("\n\tNoNPD");
        }



        // printf("\n\tEnter ID: ");
        // scanf("%d",&newNode->_id);
        newNode->_id = _id;
        printf("\n\tEnter User Name: ");
        getchar();

        // fgets(pd->_name, 256,stdin);
        // removeTrailing(pd->_name);

        scanf("%s",newNode->_uName);
        printf("\n\tEnter Password: ");
        getchar();
        scanf("%s",newNode->_passwd);


        return head;
}
int writeAlmD(AlmD *almd)
{
        FILE *fp = NULL;

        fp = fopen("ALMD.dat","w+");
        if(fp == NULL)
        {
                perror("\n\tfopen() ");
                return -1;
        }

        //fseek(fp, 0L, SEEK_END);
        if(almd == NULL)
                printf("\n\t NULL Write pd");
        while(almd != NULL){
                fprintf(fp,"%d, %s, %c\n",almd->_id,almd->_name,almd->_gender);
                //fprintf(stdout,"%d, %s, %c\n",pd->_id,pd->_name,pd->_gender);
                almd = almd->next;
        }

        fclose(fp);


}

int writeLD(LD *ld)
{
        FILE *fp = NULL;

        fp = fopen("LD.dat","w+");
        if(fp == NULL)
        {
                perror("\n\tfopen() ");
                return -1;
        }

        //fseek(fp, 0L, SEEK_END);
        if(ld == NULL)
                printf("\n\t NULL Write pd");
        while(ld != NULL){
                //printf("\n%d = %c", ld->_passwd[strlen(ld->_passwd)-1],ld->_passwd[strlen(ld->_passwd)-1]);
                fprintf(fp,"%d, %s, %s\n",ld->_id,ld->_uName,ld->_passwd);
                ld = ld->next;
        }

        fclose(fp);


}
AlmD* loadAlmD()
{
        FILE *fp = NULL;
        AlmD *newNode = NULL;
        AlmD *head = NULL;
        AlmD *almd;
        int _fSize = 0;
        char tmpBuff[256] = {'\0', };

        fp = fopen("ALMD.dat","r");
        if(fp == NULL)
        {
                perror("\n\tfopen() ");
                return NULL;
        }

        fseek(fp, 0L, SEEK_SET);
        fseek(fp, 0L, SEEK_END);
        _fSize = ftell(fp);
        // printf("\n\tFile Size: %d\n",_fSize);

        if(_fSize == 0) /* No records */
        {
                head = NULL;
        }
        else
        {
                fseek(fp, 0L, SEEK_SET);
                memset(tmpBuff,'\0', 256);
                // head = newNode;
                while(fgets(tmpBuff, 256, fp)){

                        if(head == NULL) /* first record */
                        {
                                newNode = (AlmD *)malloc(sizeof(AlmD));
                                newNode->next = NULL;
                                head = newNode;
                                almd = newNode;
                                tokenizeAlmD(newNode, tmpBuff);

                        }
                        else /* rest of the records */
                        {
                                newNode = (AlmD *)malloc(sizeof(AlmD));
                                newNode->next = NULL;
                                almd->next = newNode;
                                tokenizeAlmD(newNode, tmpBuff);
                                almd = almd->next;
                        }

                }

        }

        fclose(fp);
        // printf("\n\tHead : %u\nlast node: %u\n", head, pd);
        return head;

}


LD* loadLD()
{
        FILE *fp = NULL;
        LD *newNode = NULL;
        LD *head = NULL;
        LD *ld;
        int _fSize = 0;
        char tmpBuff[256] = {'\0', };

        fp = fopen("LD.dat","r");
        if(fp == NULL)
        {
                perror("\n\tfopen() ");
                return NULL;
        }

        fseek(fp, 0L, SEEK_SET);
        fseek(fp, 0L, SEEK_END);
        _fSize = ftell(fp);
        // printf("\n\tFile Size: %d\n",_fSize);

        if(_fSize == 0) /* No records */
        {
                head = NULL;
        }
        else
        {
                fseek(fp, 0L, SEEK_SET);
                memset(tmpBuff,'\0', 256);
                // head = newNode;
                while(fgets(tmpBuff, 256, fp)){

                        if(head == NULL) /* first record */
                        {
                                newNode = (LD *)malloc(sizeof(LD));
                                newNode->next = NULL;
                                head = newNode;
                                ld = newNode;
                                tokenizeLD(newNode, tmpBuff);

                        }
                        else /* rest of the records */
                        {
                                newNode = (LD *)malloc(sizeof(LD));
                                newNode->next = NULL;
                                ld->next = newNode;
                                tokenizeLD(newNode, tmpBuff);
                                ld = ld->next;
                        }


                }

        }

        fclose(fp);
        // printf("\n\tHead : %u\nlast node: %u\n", head, pd);
        return head;

}
JP* loadJP()
{
        FILE *fp = NULL;
        JP *newNode = NULL;
        JP *head = NULL;
        JP *jp;
        int _fSize = 0;
        char tmpBuff[256] = {'\0', };

        fp = fopen("JP.dat","r");
        if(fp == NULL)
        {
                perror("\n\tfopen() ");
                return NULL;
        }

        fseek(fp, 0L, SEEK_SET);
        fseek(fp, 0L, SEEK_END);
        _fSize = ftell(fp);
if(_fSize == 0) /* No records */
        {
                head = NULL;
        }
        else
        {
                fseek(fp, 0L, SEEK_SET);
                memset(tmpBuff,'\0', 256);
                // head = newNode;
                while(fgets(tmpBuff, 256, fp)){

                        if(head == NULL) /* first record */
                        {
                                newNode = (JP *)malloc(sizeof(JP));
                                newNode->next = NULL;
                                head = newNode;
                                jp = newNode;
                                tokenizeJP(newNode, tmpBuff);

                        }
                        else /* rest of the records */
                        {
                                newNode = (JP *)malloc(sizeof(JP));
                                newNode->next = NULL;
                                jp->next = newNode;
                                tokenizeJP(newNode, tmpBuff);
                                jp = jp->next;
                        }


                }

        }

        fclose(fp);
        // printf("\n\tHead : %u\nlast node: %u\n", head, pd);
        return head;

}

int readAlmd(AlmD *almd)
{
        FILE *fp = NULL;
        char tmpBuff[256] = {'\0', };
        AlmD tmppd;

        fp = fopen("ALMD.dat","r");
        if(fp == NULL)
        {
                perror("\n\tfopen() ");
                return -1;
        }

        fseek(fp, 0L, SEEK_SET);
        memset(tmpBuff,'\0', 256);
        while(fgets(tmpBuff, 256, fp)){

                // printf("\n\tRead Buff: %s", tmpBuff);
                tokenizeAlmD(&tmppd, tmpBuff);
                memset(tmpBuff,'\0', 256);
        }

        fclose(fp);


}

int tokenizeAlmD(AlmD *almd, char *tmpBuff)
{
        char *tokens;
        int i, count;
        char *tmpBuff1;

        tokens = strtok(tmpBuff, ",");
        almd->_id = atoi(tokens);

        tokens = strtok(NULL, ",");
        removeLeading(tokens,almd->_name);

        tokens = strtok(NULL, ",");
        removeLeading(tokens,tokens);
tokens = strtok(NULL, ",");
        removeLeading(tokens,tokens);
        removeTrailing(tokens);
        almd->_gender = tokens[0];
}


int tokenizeLD(LD *ld, char *tmpBuff)
{
        char *tokens;
        int i, count;
        char *tmpBuff1;

        tokens = strtok(tmpBuff, ",");
        ld->_id = atoi(tokens);

        tokens = strtok(NULL, ",");
        removeLeading(tokens,ld->_uName);

        tokens = strtok(NULL, ",");
        removeLeading(tokens,ld->_passwd);
        removeTrailing(ld->_passwd);
        //dispPD(pd);
}

int tokenizeJP(JP *jp, char *tmpBuff)
{
        char *tokens;
        int i, count;
        char *tmpBuff1;

        tokens = strtok(tmpBuff, ",");
        jp->_id = atoi(tokens);

        tokens = strtok(NULL, ",");
        removeLeading(tokens,jp->jobTitle);

        tokens = strtok(NULL, ",");
        removeLeading(tokens,tokens);
        removeTrailing(tokens);
}

void removeLeading(char *str, char *str1)
{
    int idx = 0, j, k = 0;

    // Iterate String until last
    // leading space character
while (str[idx] == ' ' || str[idx] == '\t' || str[idx] == '\n')
    {
        idx++;
    }

    // Run a for loop from index until the original
    // string ends and copy the content of str to str1
    for (j = idx; str[j] != '\0'; j++)
    {
        str1[k] = str[j];
        k++;
    }

    // Insert a string terminating character
    // at the end of new string
    str1[k] = '\0';

    // Print the string with no whitespaces
    //printf("%s", str1);
}

void removeTrailing(char *str)
{
        if((str[strlen(str)-1] == ' ' || str[strlen(str)-1] == '\t' || str[strlen(str)-1] == '\n'))
    {
        str[strlen(str)-1] = '\0';
    }

}


int alumni_Login(LD *head)
{
        LD _ld;
        int flag = 0;

        printf("\n\tEnter User Name: ");
        scanf("%s", _ld._uName);
        printf("\n\tEnter Password: ");
        scanf("%s",_ld._passwd);
        while(head != NULL)
        {
                if((strcmp(head->_uName, _ld._uName)==0)&&(strcmp(head->_passwd, _ld._passwd)==0))
                {
                        flag = 1;
                        break;
                }
                head = head->next;
}

        if(flag == 1)
                return 1;
        return 0;
}
int edit_details(AlmD *almd)
{
        FILE *fp = NULL;

        fp = fopen("ALMD.dat","w+");
        if(fp == NULL)
        {
                perror("\n\tfopen() ");
                return -1;
        }

        //fseek(fp, 0L, SEEK_END);
        if(almd == NULL)
                printf("\n\t NULL Write almd");
        while(almd != NULL){
                fprintf(fp,"%d, %s, %c,%s,%s,%s,%s,%d,%s,%s,%s,%s,%d\n",almd->_id,almd->_name,almd->_gender,
         almd->telephoneNo,
         almd->address,
         almd->emailId,
         almd->department,
         almd->salary,
         almd->designation,
         almd->technology,
        almd->company,
        almd->location,
        almd->yearsOfExperience);
                //fprintf(stdout,"%d, %s, %c\n",pd->_id,pd->_name,pd->_gender);
                almd = almd->next;
        }

        fclose(fp);


}
AlmD* alumni_get_data(AlmD *almd, int *_id)
{
        AlmD *newNode =NULL;
        AlmD *head = NULL;
        head = almd;

        newNode = (AlmD *)malloc(sizeof(AlmD));
        newNode->next = NULL;
if(head == NULL)
        {
                //no records
                head = newNode;
                almd = newNode;
                printf("\n\tNNPD");
        }
        else
        {
                //records are present
                while(almd->next != NULL)
                        almd = almd->next;

                almd->next = newNode;
                almd = almd->next;
                printf("\n\tNoNPD");
        }

        //pd = newNode;

        printf("\n\tEnter ID: ");
        scanf("%d",&newNode->_id);
        printf("\n\tEnter Name: ");
        getchar();

        // fgets(pd->_name, 256,stdin);
        // removeTrailing(pd->_name);

        scanf("%[^\n]s",newNode->_name);
        printf("\n\tEnter Gender (M/F/O): ");
        getchar();
        scanf("%c",&newNode->_gender);
        printf("\n\tEnter Telephone No: ");
                scanf("%s",newNode->telephoneNo);
        printf("\n\tEnter Address: ");
        getchar();
        scanf("%[^\n]s",newNode->address);
                printf("\n\tEnter EmailId: ");
        getchar();
        scanf("%[^\n]s",newNode->emailId);
                printf("\n\tEnter Department: ");
        getchar();
        scanf("%[^\n]s",newNode->department);
                printf("\n\tEnter salary: ");
        scanf("%d",&newNode->salary);
                printf("\n\tEnter designation: ");
        getchar();
        scanf("%[^\n]s",newNode->designation);
printf("\n\tEnter technology: ");
        getchar();
        scanf("%[^\n]s",newNode->technology);
                printf("\n\tEnter company: ");
        getchar();
        scanf("%[^\n]s",newNode->company);
                printf("\n\tEnter location: ");
        getchar();
        scanf("%[^\n]s",newNode->location);
                printf("\n\tEnter yearsOfExperience: ");
scanf("%d",&newNode->yearsOfExperience);
        *_id = newNode->_id;

        return head;
}
JP* create_posts(JP* jp,int* _id){
JP *newNode =NULL;
        JP *head = NULL;
        head = jp;

        newNode = (JP *)malloc(sizeof(JP));
        newNode->next = NULL;

        if(head == NULL)
        {
                //no records
                head = newNode;
                jp = newNode;
                printf("\n\tNNJP");
        }
        else
        {
                //records are present
                while(jp->next != NULL)
                        jp = jp->next;

                jp->next = newNode;
                jp = jp->next;
                printf("\n\tNoNJP");
        }

        //jp = newNode;

        printf("\n\tEnter ID: ");
        scanf("%d",&newNode->_id);
        printf("\n\tEnter Job Title: ");
        getchar();

// fgets(jp->_name, 256,stdin);
        // removeTrailing(jp->_name);

        scanf("%[^\n]s",newNode->jobTitle);
        printf("\n\tEnter Job description: ");
        getchar();
        scanf("%s",newNode->jobDescription);
        *_id = newNode->_id;

        return head;
}
void view_Profile(AlmD *almd)
{
        while(almd != NULL){
                printf("\n\tID: ");
                printf("%d",almd->_id);
                printf("\tName: ");
                printf("%s",almd->_name);
                printf("\tGender (M/F/O): ");
                printf("%c",almd->_gender);
                printf("\n\t Telephone No: ");
                printf("%s",almd->telephoneNo);
        printf("\n\t Address: ");
        printf("%s",almd->address);
                printf("\n\t EmailId: ");
        printf("%s",almd->emailId);
                printf("\n\t Department: ");
        printf("%s",almd->department);
                printf("\n\t salary: ");
        printf("%d",almd->salary);
                printf("\n\t designation: ");
        printf("%s",almd->designation);
                printf("\n\t technology: ");
        printf("%s",almd->technology);
                printf("\n\t company: ");
        printf("%s",almd->company);
                printf("\n\t location: ");
        printf("%s",almd->location);
                printf("\n\t yearsOfExperience: ");
printf("%d",almd->yearsOfExperience);
                almd = almd->next;
        }
}
void view_posts(JP* jp){
        while(jp != NULL){
                        printf("\n\t ID: ");
        printf("%d",jp->_id);
        printf("\n\t Job Title: ");
        printf("%s",jp->jobTitle);
printf("\n\tJob description: ");
        printf("%s",jp->jobDescription);
                jp=jp->next;
        }
}









