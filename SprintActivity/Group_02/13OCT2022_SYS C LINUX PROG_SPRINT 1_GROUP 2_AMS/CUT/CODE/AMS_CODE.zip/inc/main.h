char WelcomeMsg[50] = "\n\t=============Welcome=============";
char MainMenu[] = "\n\n\tPress,\n\t1. Alumni\n\t2. Student\n\t3. Exit\n\tChoice: ";
char AdminMenu[]="\n\n\tPress,\n\t1. Edit Alumni\n\t2. Delelte Alumni\n\t3. Report non placed students\n\t5.Exit\n\tChoice: ";
char AlumniMenu[]="\n\n\tPress,\n\t1. Sign Up\n\t2. Log In\n\t3. Exit\n\tChoice: ";
char StudentMenu[]="\n\n\tPress,\n\t1. Sign Up\n\t2. Log In\n\t3. Exit\n\tChoice: ";
