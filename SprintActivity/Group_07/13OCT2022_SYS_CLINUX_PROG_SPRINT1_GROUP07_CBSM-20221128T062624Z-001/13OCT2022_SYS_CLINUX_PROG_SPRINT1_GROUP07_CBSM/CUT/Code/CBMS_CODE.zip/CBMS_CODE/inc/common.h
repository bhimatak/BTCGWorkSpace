/*************************************************************************
*                               MACROS
*************************************************************************/
#ifndef COMMON_H
#define COMMON_H
/*************************************************************************
*                               HEADER FILES
*************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int mainMenu();
int custMainMenu();
int driverMenu();
void removeLeading(char *, char *);
void removeTrailing(char *);

#endif
/*END OF MACRO*/



