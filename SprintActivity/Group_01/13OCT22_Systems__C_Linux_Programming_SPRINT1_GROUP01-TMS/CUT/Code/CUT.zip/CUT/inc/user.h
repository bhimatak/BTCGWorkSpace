/***********************************************************************************************************************************
 * *  FILE NAME : task.h
 * *
 * * DESCRIPTION : This file includes all header files wich holds .c files
 * *
 * *REVISION HISTORY :
 * *
 * *  DATE                      NAME                                          REFERENCE                        REASON
 * * ---------------------------------------------------------------------------------------------------------------------------------
 * *  24-NOV-2022              Group1                                           NEW                           SPLINT ProjECT
 * *
 * * copyright @Aricent
 * * *************************************************************************************************************************************/
#ifndef USER_H
#define USER_H
#define MAX_USER_NAME_LEN 80
#define MAX_USER_DESIGNATION_LEN 100
#define MAX_USER_NUM 50
typedef struct USER
{
	int user_id;
	char user_name[MAX_USER_NAME_LEN];
	char user_designation[MAX_USER_DESIGNATION_LEN];
}USER;
int load_user_data(char*);
int save_user_data(char*);
void display_user_data();
int create_user(USER*);
int search_user(int);
int update_user(int);
int delete_user(int);
#endif
