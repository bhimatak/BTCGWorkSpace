/************************************************************************************************************************************
 * * **********************************************************************************************************************************
 * *  FILE NAME : common.h
 * *
 * * DESCRIPTION : it includes all the header files include in .c files.
 * * 
 * * REVISION HISTORY :
 * *  
 * *  DATE                      NAME                                          REFERENCE                        REASON
 * *---------------------------------------------------------------------------------------------------------------------------------
 * *  24-NOV-2022              Group1                                           NEW                           SPLINT ProjECT
 * *  
 * * copyright @Aricent
 * * ********************************************************************************************************************************/

#ifndef COMMON_H
#define COMMON_H
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <ctype.h>

#define SUCCESS 1
#define FAILURE 0

#define MAX_LINE_LENGTH 256
#define MAX_FILENAME_LENGTH 256

#endif
