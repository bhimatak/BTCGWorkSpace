/************************************************************************************************************************************
 * * **********************************************************************************************************************************
 * *  FILE NAME : task.h
 * *
 * * DESCRIPTION : This file includes all header files wich holds .c files
 * * 
 * * REVISION HISTORY :
 * *  
 * *  DATE                      NAME                                          REFERENCE                        REASON
 * * ---------------------------------------------------------------------------------------------------------------------------------
 * *  24-NOV-2022              Group1                                           NEW                           SPLINT ProjECT
 * *  
 * * copyright @Aricent
 * *************************************************************************************************************************************/
#ifndef TASK_H
#define TASK_H
#define MAX_TASK_NAME_LEN 80 
#define MAX_TASK_DESCRIPTION 256
#define MAX_TASK_DEADLINE 50
#define MAX_TASK_NUM 50

typedef struct TASK
{
	int task_id;
	char task_name[MAX_TASK_NAME_LEN];
	char task_description[MAX_TASK_DESCRIPTION];
	char task_deadline[MAX_TASK_DEADLINE];
}TASK;
int load_task_data(char*);
int save_task_data(char*);
void display_task_data();
int create_task(TASK*);
int search_task(int);
int  update_task(int);
int delete_task(int);
bool format_error_check(char*);
#endif
