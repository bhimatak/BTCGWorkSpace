/************************************************************************************************************************************
 *  **********************************************************************************************************************************
 * *  FILE NAME : assignment.h
 * *
 * * DESCRIPTION : This file includes all header files wich holds .c files
 * *
 * * REVISION HISTORY :
 * *
 * *  DATE                      NAME                                          REFERENCE                        REASON
 * * ---------------------------------------------------------------------------------------------------------------------------------
 * *  24-NOV-2022              Group1                                           NEW                           SPLINT ProjECT
 * *
 * * * copyright @Aricent
 * * *************************************************************************************************************************************/
#ifndef ASSIGNMENT_H_
#define ASSIGNMENT_H_
#define MAX_ASSIGNMENT_NUM 100
typedef struct ASSIGNMENT
{
	int task_id;
	int user_id;
}ASSIGNMENT;
int save_assignment_data();
#endif
