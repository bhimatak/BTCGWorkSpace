/************************************************************************************************************************************
 * * **********************************************************************************************************************************
 * * * FILE NAME : user.c
 * * *
 * * * DESCRIPTION : This file perform operations on user records.
 * * *
 * * * REVISION HISTORY :
 * * *
 * * * DATE                      NAME                                          REFERENCE                        REASON
 * * ---------------------------------------------------------------------------------------------------------------------------------
 * * *24-NOV-2022              Group1                                           NEW                           SPLINT ProjECT
 * * *
 * * *copyright @Aricent
 * * *********************************************************************************************************************************/


#include "common.h"
#include "user.h"

USER user_list[MAX_USER_NUM]; //calling structure from user.h file
int num_user = 0;

/********************************************************************************************************
 * * *FUNCTION NAME:create_user()
 * * *DESCRIPTION:This function calls the required function to create user record.
 * * *RETURNS:SUCCESS and in case of failure ERROR
 * * *****************************************************************************************************/
int create_user(USER *p_user)
{
	user_list[num_user] = *p_user;
	num_user++;
	return SUCCESS;
}
/******************************************************************************************************************
 * * *FUNCTION NAME:load_user_data()
 * * *DESCRIPTION:This function calls the required function to perform the operations on displaying the load user datay.
 * * *RETURNS:SUCCESS and in case of failure ERROR
 * * **************************************************************************************************************/
int load_user_data(char *user_csv) 
{
	FILE *fp;

	int user_id; 
        char user_name[MAX_USER_NAME_LEN];
        char user_designation[MAX_USER_DESIGNATION_LEN];
        char line[MAX_LINE_LENGTH];
        char *ret_str;
	int ret;
	fp=fopen(user_csv,"r");
       	if(fp == NULL)
       	{
		printf("could not open file");
		perror(user_csv);
		return FAILURE;
	}
	num_user = 0;
	char USER_ID[20]="USER ID:",USER_NAME[20]="USER NAME:",USER_DESIGNATION[20]="USER DESIGNATION:";
	        printf("%-10s%-20s%-30s\n",USER_ID,USER_NAME,USER_DESIGNATION);
       	while((ret_str = fgets(line, MAX_LINE_LENGTH, fp))!=NULL)
	  {
		  line[strlen(line) -1 ]= '\0';
		  ret = sscanf(line,"%d,%[^,],%[^,]",&user_id,user_name,user_designation);
		  if(ret==3) 
		  {
			  printf("%-10d%-20s%-30s\n",user_id,user_name,user_designation);
			  user_list[num_user].user_id=user_id;
			  strcpy(user_list[num_user].user_name, user_name);
			  strcpy(user_list[num_user].user_designation, user_designation);

			  num_user++;
		  }
	  }
	(void)fclose(fp);
       	return SUCCESS;
}
/********************************************************************************************************
 * * *FUNCTION NAME:save_user_data()
 * * *DESCRIPTION:This function calls the required function to save the user record in user.csv file.
 * * *RETURNS:SUCCESS and in case of failure ERROR
 * * *****************************************************************************************************/
int save_user_data(char *user_csv)
{
       	FILE * fp;
       	int i;
       	fp=fopen(user_csv,"w");
       	if(fp == NULL)
       	{
	 printf("could not openfile");
       	 perror(user_csv);
	 return FAILURE;
       	}
       	for(i=0;i< num_user;i++)
	
	       	fprintf(fp,"%d, %s, %s\n",user_list[i].user_id,user_list[i].user_name,user_list[i].user_designation);
	
	(void)fclose(fp);
	return SUCCESS;
}
/*******************************************************************************************************************
 * *FUNCTION NAME:display_user_data()
 * * *DESCRIPTION:This function calls the required function to display the user data which is present in user.csv file.
 * * *RETURNS:SUCCESS and in case of failure ERROR
 * * *****************************************************************************************************/
void display_user_data()
{
	int i;
	for(i=0;i<num_user;i++)
		printf("user[%d]=<%d,%s,%s>\n",(i+1),user_list[i].user_id,user_list[i].user_name,user_list[i].user_designation);
}
	 
/***********************************************************************************************************************
 * * *FUNCTION NAME:search_user()
 * * *DESCRIPTION:This function calls the required function to search a particular user which is present on user.csv file
 * * *RETURNS:SUCCESS and in case of failure ERROR
 * * *****************************************************************************************************/
int  search_user(int user_id)
{
	int i;
	for(i=0;i<num_user;i++)
	{
		if(user_id==user_list[i].user_id)
		{
			 printf("user[%d]=<%d,%s,%s>\n",(i+1),
					 user_list[i].user_id,user_list[i].user_name,
					 user_list[i].user_designation);
			 return SUCCESS;
		}
	}
	return FAILURE;
}
/********************************************************************************************************
* * *FUNCTION NAME:update_user()
* * *DESCRIPTION:This function calls the required function to update the user record.
* * *RETURNS:SUCCESS and in case of failure ERROR
* * *****************************************************************************************************/
int update_user(int user_id)
{
	int i;
	char user_name[MAX_USER_NAME_LEN];
	char user_designation[MAX_USER_DESIGNATION_LEN];
	for(i=0;i<num_user;i++)
	{
		if(user_id==user_list[i].user_id)
		{
		printf("enter user_name, user_designation \n");
		(void)scanf("%s%s", user_name, user_designation  );
			strcpy(user_list[i].user_name,user_name);
			strcpy(user_list[i].user_designation,user_designation);
			return SUCCESS;
		}
	}
	return FAILURE;
}
/********************************************************************************************************
 * * *FUNCTION NAME:delete_user()
 * * *DESCRIPTION:This function calls the required function to delete the particular user.
 * * *RETURNS:SUCCESS and in case of failure ERROR
 * * *****************************************************************************************************/	

int delete_user( int user_id)
{
	int i ;
	bool flag=0;
       	for(i=0;i<num_user;i++)
       	{
	       	if(user_id==user_list[i].user_id)
	       	{
			flag=1;
	       	}
	       	if(flag){
		       	user_list[i].user_id = user_list[i+1].user_id;
		       	strcpy(user_list[i].user_name, user_list[i+1].user_name);
		        strcpy(user_list[i].user_designation, user_list[i+1].user_designation);
		}
									       
       	}
       	if(flag){
	       	num_user--;
	       	return SUCCESS;
       	}
       	return FAILURE;
}
	

