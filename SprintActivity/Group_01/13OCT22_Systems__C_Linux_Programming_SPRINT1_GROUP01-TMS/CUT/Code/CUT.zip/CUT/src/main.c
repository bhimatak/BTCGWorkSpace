/************************************************************************************************************************************
 * **********************************************************************************************************************************
 * * FILE NAME : main.c
 * *
 * * DESCRIPTION : This file shows menu and sub-menu part to perform operations on tasks and users
 * *
 * * REVISION HISTORY :
 * * 
 * * DATE                      NAME                                          REFERENCE                        REASON
 * ---------------------------------------------------------------------------------------------------------------------------------
 * * 24-NOV-2022              Group1                                           NEW                           SPLINT ProjECT
 * *
 * *copyright @Aricent
 * *********************************************************************************************************************************/

#include "common.h"
#include "task.h"
#include "user.h"
#include "config.h"
#include "assignment.h"
struct login
{
       	char username[10];
	char password[10];
}*pUser;

/********************************************************************************************************
 * * *FUNCTION NAME:userlogin()
 * * *DESCRIPTION:This function calls the required function to perform the login operation
 * * *RETURNS:SUCCESS and in case of failure ERROR
 ** *****************************************************************************************************/
int userlogin()
{
    	FILE *fp;
    	char uName[10], pwd[10]; 
	/*global variable declaration*/
    	int i;
    	int out=0;
    	char c;
	int u,p;
	int defined_pin=1234;
	int pin;
    	pUser=(struct login *)malloc(sizeof(struct login));
	
    	printf("\t1. Login Through An Existing Account\n\t2. Create New account\n\t3. To Exit\n");
    	printf("\n\t ENTER Choice : ");
    	(void)scanf("%d",&i);
    	
	switch(i)
	{
		case 1:
	    	    	u=0;
	    	    	p=0;
		    	if ( ( fp=fopen("login_user.dat", "r+")) == NULL) 
		    	{
		        	if (( fp=fopen("login_user.dat", "w+")) == NULL) 
		        	{
		            		printf ("Could not open file\n");
		            		exit (EXIT_FAILURE);
		        	}
		    	}
		    	
	    	    	printf("\n\tENTER Username and Password\n");
		    	printf("\tUsername: ");
		    	(void)scanf("%9s",uName);
		    	printf("\tPassword: ");
		    	(void)scanf("%9s",pwd);
		    	while ( fread (pUser, sizeof(struct login), 1, fp) == 1) 
		    	{
		        	if( strcmp ( pUser->username, uName) == 0) 
		        	{
		            		u=1;
		            		if( strcmp ( pUser->password, pwd) == 0) 
		            		{
		                		p=1;
		            		}
		        	}
		    	}
		    	if(u==1 && p==1)
		    	{
		    		printf("\n\tLOGIN SUCCESSFUL \n");
		    		out=1;;
		    	}
		    	else
		    	{
		    		printf("\tLOGIN UNSUCCESSFUL\n");
		    		out=0;
		    	}
		    	fclose(fp);
		    	break;

		case 2:
			printf("\tENTER PIN TO CONTINUE : ");
		        (void)scanf("%d",&pin);
		        if(pin==defined_pin)
		        {
			    	do
			    	{
					if ( ( fp=fopen("login_user.dat", "a+")) == NULL) 
					{
				    		if ( ( fp=fopen("login_user.dat", "w+")) == NULL) 
				    		{
				        		printf ("\tCould not open file\n");
				        		exit (EXIT_FAILURE);
				    		}
					}
					printf("\tChoose A Username: ");
					(void)scanf("%9s",pUser->username);
					printf("\tChoose A Password: ");
					(void)scanf("%9s",pUser->password);
					fwrite (pUser, sizeof(struct login), 1, fp);
					printf("\tAdd another account? (Y/N): ");
					(void)scanf(" %c",&c);
			    	}while(c=='Y'||c=='y');
			    	printf("\tSIGNUP SUCCESSFUL\n\tPLEASE REOPEN THE APPLICATION\n");
		    	}
		    	else
		    	{
		    		printf("\n\t**INVALID PIN**\n");
		    	}
		    	fclose(fp);
		    	break;
		    	case 3:
		    		break;
		    		
		    	default:
		    		printf("Wrong input");
		    		
	    	}
	free (pUser);
	
    	return out;
}
/********************************************************************************************************
 * * *FUNCTION NAME:create()
 * * *DESCRIPTION:This function calls the required function to perform CRUD Operations..
 * * *RETURNS:SUCCESS and in case of failure ERROR
 * * *****************************************************************************************************/
void create()
{
	int ch, ret; 
	bool val=false;
	char taskname[100];
	char taskdesc[100];
	char username[100];
	char userdesc[100];
	char filename[MAX_FILENAME_LENGTH];
	TASK task;/*for input/output*/
	USER user;
	int task_id;
	int user_id;
	int a;
	while(1)
	{
		printf("\n******************************SUB-MENU******************************************\n");
		printf("\nPlease enter your choice.\n");
		printf("\n1. Create Task  Record\n");
		printf("\n2. Create User  Record\n");
		printf("\n3. Save Task data to file\n");
		printf("\n4. Save User data to file\n");
		printf("\n5. Back to Main Menu\n");
		printf("Enter choice: ");
		scanf("%d", &ch);
		if(ch==5)
			break;
		switch(ch){
			case 1:/*Add Task Record*/
				{
					printf("Enter task_id:");
					scanf("%d", &(task.task_id));
					while(!val)
					{
						printf("Enter task_name:");
						scanf("%s",taskname);
						val =format_error_check(taskname);
						if(!val)
							printf("Please enter a valid task name!!!!\n");
					}
					strcpy(task.task_name,taskname);
					val=false;
					while(!val)
					{
						printf("Enter task_Description:");
						scanf("%s",taskdesc);
						val =format_error_check(taskdesc);
						if(!val)
							printf("Please enter a valid task description!!!!\n");
					}
					strcpy(task.task_description,taskdesc);
					val=false;
					printf("Enter task_deadline :");
					scanf("%s",task.task_deadline);
					ret = create_task(&task);
					if (ret == FAILURE)
						printf("Failed to add task\n");
					else
						printf("Task added successfully\n");
					break;
				 }
			case 2:/*Add User Record*/
				{
					printf("Enter user_id:");
					scanf("%d", &(user.user_id));
					while(!val)
					{
						printf("Enter user_name:");
						scanf("%s",username);
						val =format_error_check(username);
						if(!val)
							printf("Please enter a valid user name!!!!\n");
					}
					strcpy(user.user_name,username);
					val=false;
					while(!val)
					{
						printf("Enter user_designation:");
						scanf("%s",userdesc);
						val =format_error_check(userdesc);
						if(!val)
							printf("Please enter a valid user designation!!!!\n");
					}
					strcpy(user.user_designation,userdesc);
					val=false;
					ret = create_user(&user);
					if (ret == FAILURE)
						printf("Failed to add user\n");
					else
						printf("User added Successfully\n");
					break;
				}
				case 3:/*Save task Record*/
				{
					printf("Enter filename : ");
					scanf("%s", filename);
					ret = save_task_data(filename);
					if (ret == FAILURE)
						printf("Failed to save data\n");
					else
						printf("Saved data successfully\n");
					break;
				}
				case 4:/*Save User Data*/
				{
					printf("Eter filename: ");
					scanf("%s", filename);
					ret = save_user_data(filename);
					if (ret == FAILURE)
						printf("Failed to save data\n");
					else
						printf("Saved data successfully\n");
					break;
				}
				default:
				       	{
						printf("Invalid option. Please try again...\n");
						break;
					}
		}
	}
}
/********************************************************************************************************
 * * *FUNCTION NAME:load()
 * * *DESCRIPTION:This function calls the required function to perform load the details from task_csv and user_csv.
 * * *RETURNS:SUCCESS and in case of failure ERROR
 * * *****************************************************************************************************/
void load()
{
	int ch, ret;
	bool val=false;
	char taskname[100];
	char taskdesc[100];
	char username[100];
	char userdesc[100];
	char filename[MAX_FILENAME_LENGTH];
	TASK task;/*for input/output*/
	USER user;
	int task_id;
	int user_id;
	int a;
	while(1)
	{
		printf("\n******************************SUB-MENU******************************************\n");
		printf("\nPlease enter your choice.\n");
		printf("\n1. Load Task Data From File\n");
		printf("\n2. Load User Data From File\n");
		printf("\n3. Back to Main Menu\n");
		printf("Enter choice: ");
		scanf("%d", &ch);
		if(ch==3)
			break;
		switch(ch){
			case 1:/*Load task data from file*/
				{
					printf("enter filename :");
					scanf("%s",filename);
					ret = load_task_data(filename);
					if (ret == FAILURE)
						printf("Failed to load data\n");
					else
						printf("Loaded data successfully\n");
					break;
				}
			case 2:/*load user data from file*/
				         {
						 printf("Enter filename: ");
						 scanf("%s", filename);
						 ret = load_user_data(filename);
						 if (ret == FAILURE)
							 printf("Failed to load data\n");
						 else
							 printf("Loaded data successfully\n");
						 break;
					 }
			                 default:
					 {
						 printf("Invalid option. Please try again...\n");
						 break;
					 }
		}
	}
}
/********************************************************************************************************
 * * *FUNCTION NAME:update()
 * * *DESCRIPTION:This function calls the required function to perfrom update records on users and tasks
 * * *RETURNS:SUCCESS and in case of failure ERROR
 * * *****************************************************************************************************/
void update()
{
	int ch, ret;
	bool val=false;
	char taskname[100];
	char taskdesc[100];
	char username[100];
	char userdesc[100];
	char filename[MAX_FILENAME_LENGTH];
	TASK task;/*for input/output*/
	USER user;
	int task_id;
	int user_id;
	int a;
	while(1)
	{
		printf("\n******************************SUB-MENU******************************************\n");
		printf("\nPlease enter your choice.\n");
		printf("\n1. Update Task Record\n");
		printf("\n2. Update User Reord\n");
		printf("\n3. Save Task data to file\n");
		printf("\n4. Save User data to file\n");
		printf("\n5. Back to Main Menu\n");
		printf("Enter choice: ");
		scanf("%d", &ch);
		if(ch==5)
			break;
		switch(ch){
			case 1:/*Update task record*/
				{
					printf("enter task_id to be update: ");
					scanf("%d", &task_id);
					ret = update_task(task_id);
					if(ret== 1)
						printf("task update sucessfully!!\n");
					else
						printf("Id is not found!!\n");
					break;
				}
			case 2:/*Update User Record*/
				{
					printf("enter user_id: ");
					scanf("%d",&user_id);
					ret = update_user(user_id);
					if(ret==1)
						printf("update sucessfull");
					else
						printf("update not sucessfull");
					break;
				}
			case 3:/*Save task Record*/
				{
					printf("Enter filename : ");
					scanf("%s", filename);
					ret = save_task_data(filename);
					if (ret == FAILURE)
						printf("Failed to save data\n");
					else
						printf("Saved data successfully\n");
					break;
				}
			case 4:/*Save User Data Record*/
				{
					printf("Eter filename: ");
					scanf("%s", filename);
					ret = save_user_data(filename);
					if (ret == FAILURE)
						printf("Failed to save data\n");
					else
						printf("Saved data successfully\n");
					break;
				}
			default:
				{
					printf("Invalid option. Please try again...\n");
					break;
				}
		}
	}
}
/********************************************************************************************************
 * * *FUNCTION NAME:delete()
 * * *DESCRIPTION:This function calls the required function to perform delete operations on tasks and users.
 * * *RETURNS:SUCCESS and in case of failure ERROR
 * * *****************************************************************************************************/
void delete()
{
	int ch, ret;
	bool val=false;
	char taskname[100];
	char taskdesc[100];
	char username[100];
	char userdesc[100];
	char filename[MAX_FILENAME_LENGTH];
	TASK task;/*for input/output*/
	USER user;
	int task_id;
	int user_id;
	int a;
	while(1)
	{
		printf("\n******************************SUB-MENU******************************************\n");
		printf("\nPlease enter your choice.\n");
		printf("\n1. Delete Task Record\n");
		printf("\n2. Delete User Record\n");
		printf("\n3. Save Task data to file\n");
		printf("\n4. Save User data to file\n");
		printf("\n5. Back to Main Menu\n");
		printf("Enter choice: ");
		scanf("%d", &ch);
		if(ch==5)
		break;
		switch(ch){
			case 1:/*Delete task record*/
				 {
					 int id;
					 printf("enter task_id you want to delete: ");
					 scanf("%d", &id);
					 ret = delete_task(id);
					 if(ret==1)
						 printf("task delete successfully!!\n");
					 else
						 printf("Id is not found!!\n");
					 break;
				 }
			 case 2:/*Delete user record*/
				 {
					 int id;
					 printf("enter the user_id you want to delete:");
					 scanf("%d",&id);
					 ret = delete_user(id);
					 if(ret==1)
						 printf("user delete sucessfully!!\n");
					 else
						 printf("Id is not found!!\n");
					 break;
				 }
			 case 3:/*Save task Record*/
				 {
					 printf("Enter filename : ");
					 scanf("%s", filename);
					 ret = save_task_data(filename);
					 if (ret == FAILURE)
						 printf("Failed to save data\n");
					 else
						 printf("Saved data successfully\n");
					 break;
				 }
			 case 4:/*Save User Data Record*/
				 {
					 printf("Eter filename: ");
					 scanf("%s", filename);
					 ret = save_user_data(filename);
					 if (ret == FAILURE)
						 printf("Failed to save data\n");
					 else
						 printf("Saved data successfully\n");
					 break;
				 }
			 default:
				 {
					 printf("Invalid option. Please try again...\n");
					 break;
				}
		}
	}
}
/********************************************************************************************************
 * * *FUNCTION NAME:search()
 * * *DESCRIPTION:This function calls the required function to perform  search operation on tasks and users.
 * * *RETURNS:SUCCESS and in case of failure ERROR
 * * *****************************************************************************************************/
void search()
{
	int ch, ret;
	bool val=false;
	char taskname[100];
	char taskdesc[100];
	char username[100];
	char userdesc[100];
	char filename[MAX_FILENAME_LENGTH];
	TASK task;/*for input/output*/
	USER user;
	int task_id;
	int user_id;
	int a;
	while(1)
	{
		printf("\n******************************SUB-MENU******************************************\n");
		printf("\nPlease enter your choice.\n");
		printf("\n1. Search Task Record\n");
		printf("\n2. Search User Record\n");
		printf("\n3. Back to Main Menu\n");
		printf("Enter choice: ");
		scanf("%d", &ch);
		if(ch==3)
			break;
		switch(ch){
			case 1:/*Search task record*/
				{
					printf("enter task_id to be search :");
					scanf("%d", &task_id);
					ret=search_task(task_id);
					if(ret == 1)
						printf("task search successfully!!\n");
					else
						printf("Id is not found!!\n");
					break;
				}
			case 2:/*Search user record*/
				{
					printf("enter the user_id to be search: ");
					scanf("%d",&user_id);
					ret= search_user(user_id);
					if(ret==1)
						printf("user search successfully!!\n");
					else
						printf("Id is not found!!\n");
					break;
				}
			default:
				{
					printf("Invalid option. Please try again...\n");
					break;
				}
		}
	}
}
/********************************************************************************************************
 * * *FUNCTION NAME:group1()
 * * *DESCRIPTION:This function calls the required function to perform  operations on main menu.
 * * *RETURNS:SUCCESS and in case of failure ERROR
 * * *****************************************************************************************************/
void group1()
{

	int ch, ret;
	bool val=false;
	char taskname[100];
	char taskdesc[100];
	char username[100];
	char userdesc[100];
	char filename[MAX_FILENAME_LENGTH];
	TASK task;// for input/output
	USER user;
	int task_id;
	int user_id;
	int a;
	
	while(1)
	{
	printf("\n***************WELCOME TO THE TASK MANAGEMENT SOFTWARE**********************\n");
	printf("\n******************************MENU******************************************\n");
	printf("\nPlease enter your choice.\n");

	printf("\n1. Create   Record\n");
	printf("\n2. Search  Record\n");
       	printf("\n3. Update  Record\n");
       	printf("\n4. Delete  Record\n");
        printf("\n5. Load  Data From File\n");
        printf("\n6. Print  List\n");
       printf("\n7. To assign Task to User\n");
       printf("\n8. Exit\n");
       
  	printf("Enter choice: ");
        scanf("%d", &ch);

  	switch(ch)
	{
	case 1:/* add task record*/
	        {
			create();
			break;
		}
	case 2:/* search task record*/
	        {
			search();
			break;
		}
	case 3: /* update task record*/
		 {
			 update();
			 break;
		 }
	case 4:/* delete task record*/
	        {
			delete();
			break;
		}
	case 5: /* load task data from file*/
		{
			load();
			break;
		}
	case 6:/*print the task details*/
		{
			display_task_data();
			break;
		}
	case 7:/*to assign task to user*/
      		{	
			a=save_assignment_data();
			break;
		}
	 case 8:/*exit*/
		{	
			exit(0);
			break;
		}
	default:
       		{	
		       	printf("Invalid option. Please try again...\n");
        	}
	}
	}
}
/********************************************************************************************************
 * * *FUNCTION NAME:main()
 * * *DESCRIPTION:This function calls the required function to perform  operations on login part.
 * * *RETURNS:SUCCESS and in case of failure ERROR
 * * *****************************************************************************************************/
int main(int argc, char *argv[])
{
	if(userlogin()==1)
		group1();
	return 0;

}




