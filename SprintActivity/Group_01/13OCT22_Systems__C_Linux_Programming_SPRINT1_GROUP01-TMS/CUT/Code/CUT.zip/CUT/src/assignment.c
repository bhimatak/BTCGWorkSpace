/************************************************************************************************************************************
 * **********************************************************************************************************************************
 * * FILE NAME : assignment.c
 * *
 * * DESCRIPTION : This file perform the operations ,to assign task id to particular user.
 * *
 * * REVISION HISTORY :
 * *
 * *DATE                      NAME                                          REFERENCE                        REASON
 * * ---------------------------------------------------------------------------------------------------------------------------------
 * * 24-NOV-2022              Group1                                           NEW                           SPLINT ProjECT
 * *
 * *copyright @Aricent
 * * *********************************************************************************************************************************/
#include "common.h"
#include "task.h"
#include "user.h"
#include "assignment.h"
#include "config.h"
/********************************************************************************************************
 * *FUNCTION NAME:userlogin()
 * *DESCRIPTION:This function calls the required function to assign task to user .
 * *RETURNS:SUCCESS and in case of failure ERROR
 * * ******************************************************************************************************/
ASSIGNMENT assignment_list[MAX_ASSIGNMENT_NUM];
int save_assignment_data(char * assignment_csv)
{
	USER user_list[MAX_USER_NUM];
	TASK task_list[MAX_TASK_NUM];
	FILE *fp;
	int user_id;
	char user_name[MAX_USER_NAME_LEN];
	char user_designation[MAX_USER_DESIGNATION_LEN];
	char line[MAX_LINE_LENGTH];
	char *ret_str;
	int ret;
	fp=fopen("user_csv","r");
	if(fp == NULL)
	{
		printf("could not open file");
		perror("user_csv");
		return FAILURE;
	}
	int num_user = 0;
	while((ret_str = fgets(line, MAX_LINE_LENGTH, fp))!=NULL)
	{
		line[strlen(line) -1 ]= '\0';
		ret = sscanf(line,"%d,%[^,],%[^,]",&user_id,user_name,user_designation);
		if(ret==3)
		{
			user_list[num_user].user_id=user_id;
			strcpy(user_list[num_user].user_name, user_name);
			strcpy(user_list[num_user].user_designation, user_designation);
			num_user++;
		}
	}
	fclose(fp);
	FILE *fp1;
	int task_id;
	char task_name[MAX_TASK_NAME_LEN];
	char task_description[MAX_TASK_DESCRIPTION];
	char task_deadline[MAX_TASK_DEADLINE];
	char line1[MAX_LINE_LENGTH];
	char *ret_str1;
	int ret1;
	fp1 = fopen("task_csv", "r");
	if(fp1 == NULL)
	{
		printf("could not open file");
		perror("task_csv");
		return FAILURE;
	}
	int num_task =0;
	while((ret_str1 = fgets(line1, MAX_LINE_LENGTH, fp1))!=NULL)
	{
		line1[strlen(line1) -1]='\0';
		ret1 = sscanf(line1, "%d,%[^,],%[^,],%[^,]", &task_id, task_name, task_description, task_deadline);
		if (ret1 == 4)
		{
			task_list[num_task].task_id = task_id;
			strcpy(task_list[num_task].task_name, task_name);
			strcpy(task_list[num_task].task_description, task_description);
			strcpy(task_list[num_task].task_deadline, task_deadline);
			num_task++;
		}
	}
	fclose(fp1);
	int num_assign=0;
	FILE *fp2;
	int i;
	int j;
	int value;
	fp2=fopen("assignment_csv","w");
	if(fp2 == NULL)
	{
		printf("could not openfile");
		perror("assignment_csv");
		return FAILURE;
	}
	for(i=0;i<num_task;i++)
	{
		for(j=0;j<num_user;j++)
		{
			value =strncmp(task_list[i].task_name,user_list[j].user_designation,4);
			if(value==0)
			{
				 printf("%d is assigned to %s and UserID is %d\n",task_list[i].task_id,user_list[j].user_name,user_list[j].user_id);
				fprintf(fp2,"%d,%d\n",user_list[j].user_id,task_list[i].task_id);
			}
		}
	}
	fclose(fp2);
	return SUCCESS;
}


