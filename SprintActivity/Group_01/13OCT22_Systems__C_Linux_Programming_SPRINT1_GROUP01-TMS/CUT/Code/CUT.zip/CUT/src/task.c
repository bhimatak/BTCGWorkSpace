/************************************************************************************************************************************
 * * **********************************************************************************************************************************
 * * * FILE NAME : task.c
 * * *
 * * * DESCRIPTION : This file will dsplay the task operations performed on task.csv file.
 * * *
 * * * REVISION HISTORY :
 * * *
 * * * DATE                      NAME                                          REFERENCE                        REASON
 * * ---------------------------------------------------------------------------------------------------------------------------------
 * * * 24-NOV-2022              Group1                                           NEW                           SPLINT ProjECT
 * * *
 * * *copyright @Aricent
 * * *********************************************************************************************************************************/



#include "common.h"
#include "task.h"
/*lobal data structure */
TASK task_list[MAX_TASK_NUM];
/*update_p update_data */
int num_task=0;
/***********************************************************************************************************************************
* * * *FUNCTION NAME:format_error_check()
* * * * *DESCRIPTION:This function calls the required function ,if any format error occurs then it skip and display the other records
* * * *RETURNS:SUCCESS and in case of failure ERROR
* * * *****************************************************************************************************/

bool format_error_check(char *str)
{
	int i;
	for(i=0;str[i]!='\0';i++)
	{
		if((int)str[i]>=65 && (int)str[i]<=90 || (int)str[i]>=97 && (int)str[i]<=122 || (int)str[i]==95)
			continue;
		else
			return false;
	}
	return true;
}


/********************************************************************************************************
 * * * *FUNCTION NAME:create_task()
 * * * *DESCRIPTION:This function calls the required function to create a task record.
 * * * *RETURNS:SUCCESS and in case of failure ERROR
 * * * *****************************************************************************************************/

int create_task(TASK *p_task)
{
	task_list[num_task]= *p_task;/* struct assignment*/
	num_task++;
	return SUCCESS;
}

/********************************************************************************************************
 * * * *FUNCTION NAME:delete_user()
 * * * *DESCRIPTION:This function read data from file name and stores in global task_list 
 * * * *RETURNS:SUCCESS and in case of failure ERROR
 * * * *****************************************************************************************************/
int load_task_data(char *task_csv)
{
	FILE *fp;
	int task_id;
	char task_name[MAX_TASK_NAME_LEN];
        char task_description[MAX_TASK_DESCRIPTION];
	char task_deadline[MAX_TASK_DEADLINE];
	char line[MAX_LINE_LENGTH];
	char *ret_str;
	int ret;
	
	fp = fopen(task_csv, "r");
	if(fp==NULL)
	{
		printf("could not open file");
		perror(task_csv);
		return FAILURE;
	}
	
	num_task =0;/*number of task records (global variable)*/
        char TASK_ID[20]="TASK ID:",TASK_NAME[20]="TASK NAME:",TASK_DESCRIPTION[20]="TASK DESCRIPTION:",TASK_DEADLINE[20]="TASK DEADLINE:";
        printf("%-10s%-20s%-30s%-20s\n",TASK_ID,TASK_NAME,TASK_DESCRIPTION,TASK_DEADLINE);
	while((ret_str = fgets(line, MAX_LINE_LENGTH, fp))!=NULL)
	{
		/* remove the newline at end*/
		line[strlen(line) -1]='\0';

		ret = sscanf(line, "%d,%[^,],%[^,],%[^,]", &task_id, task_name, task_description, task_deadline);

		if (ret == 4)
		{
			printf("%-10d%-20s%-30s%-20s\n", task_id, task_name, task_description, task_deadline);
			task_list[num_task].task_id = task_id;
			strcpy(task_list[num_task].task_name, task_name);
			strcpy(task_list[num_task].task_description, task_description);
			strcpy(task_list[num_task].task_deadline, task_deadline);
			num_task++;
		}
	}
	(void)fclose(fp);
	return SUCCESS;
}
/********************************************************************************************************
 * * * *FUNCTION NAME:save_task_data()
 * * * *DESCRIPTION:This function calls the required function to save task data from task.csv file
 * * * *RETURNS:SUCCESS and in case of failure ERROR
 * * * *****************************************************************************************************/

int save_task_data(char *task_csv)
{
	FILE * fp;
	int i;

	fp = fopen(task_csv, "w");
	if (fp ==NULL)
	{
		printf("could not open file");
		perror(task_csv);
		return FAILURE;
	}

	for(i=0; i< num_task; i++)
		fprintf(fp,"%d, %s, %s, %s\n",task_list[i].task_id,  task_list[i].task_name, task_list[i].task_description, task_list[i].task_deadline);
	
	(void)fclose(fp);
	return SUCCESS;
}
/********************************************************************************************************
 * * **FUNCTION NAME:display_task_data()
 * * *DESCRIPTION:This function calls the required function to display task data which is present in task.csv
 * * *RETURNS:SUCCESS and in case of failure ERROR
 * * * * *****************************************************************************************************/

void display_task_data()
{
	int i;

	for(i=0; i < num_task; i++)
		printf("task[%d] = <%d, %s, %s, %s>\n", (i+1),
				task_list[i].task_id,  task_list[i].task_name,
				task_list[i].task_description, task_list[i].task_deadline);
}


/********************************************************************************************************
 * * *FUNCTION NAME:save_task_data()
 * * *DESCRIPTION:This function calls the required function to search a task from task.csv file.
 * * *RETURNS:SUCCESS and in case of failure ERROR
 * * * * *****************************************************************************************************/
int search_task(int task_id)
{
	int i;
	for(i=0;i<num_task;i++)
	{
	       	if(task_id==task_list[i].task_id)
	       	{
		       	printf("task[%d]=<%d,%s,%s,%s>\n",(i+1),
					task_list[i].task_id, task_list[i].task_name,
					task_list[i].task_description, task_list[i].task_deadline);
				       	
		       	return SUCCESS;
	       	}
      	}
       	return FAILURE;
}
/********************************************************************************************************
 * * *FUNCTION NAME:save_task_data()
 * * *DESCRIPTION:This function calls the required function to update the task record .
 * * *RETURNS:SUCCESS and in case of failure ERROR
 * * *****************************************************************************************************/

int update_task(int task_id)
{
	 
	int i; 
	char task_name[MAX_TASK_NAME_LEN];
	char task_description[MAX_TASK_DESCRIPTION];
	char task_deadline[MAX_TASK_DEADLINE];
	for(i = 0; i< num_task; i++)
	{
	if(task_id == task_list[i].task_id)
	{
	printf("enter task_name, task_description, task_deadline\n");
	(void)scanf("%s%s%s", task_name, task_description, task_deadline);
	strcpy(task_list[i].task_name, task_name);
	strcpy(task_list[i].task_description, task_description);
	strcpy(task_list[i].task_deadline, task_deadline);
	return SUCCESS;
	}
	}
	return FAILURE;
}
/********************************************************************************************************
 * *FUNCTION NAME:save_task_data()
 * *DESCRIPTION:This function calls the required function to delete a  task data from task.csv file
 * *RETURNS:SUCCESS and in case of failure ERROR
 * ****************************************************************************************************/

int delete_task(int task_id)
{
	int i;
	bool flag=0;
	for(i=0;i<num_task;i++)
	{
		if(task_id==task_list[i].task_id)
		{
			flag=1;
		}
		if(flag){
			
			task_list[i].task_id = task_list[i+1].task_id;
			strcpy(task_list[i].task_name, task_list[i+1].task_name);
			strcpy(task_list[i].task_description, task_list[i+1].task_description);
			strcpy(task_list[i].task_deadline, task_list[i+1].task_deadline);
		}
	}
	if(flag){
		
		num_task--;
		return SUCCESS;
	}
	return FAILURE;
}
